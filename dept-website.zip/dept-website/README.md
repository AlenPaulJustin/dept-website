# College Department Website (HTML)

Assignment 2 - HTML Website

**Name:** Alen Paul Justin
**Roll No:** 26
**Reg No:** FIT23CS026

A simple multi-section website for the Department of Computer Science and Engineering built with HTML and CSS.

## Features
- Document structure, headings, paragraphs and text formatting
- Ordered and unordered lists
- Hyperlinks (external, internal, email)
- Image using the `<img>` tag
- Faculty table (5 members)
- Student enquiry form
- Semantic elements: `header`, `nav`, `main`, `section`, `article`, `footer`

## How to run
Download or clone the repo and open `index.html` in any web browser.
